/**
 * 模块JavaScript
 */
var home = {
    data:{

    },
    init: function () {

    },
};